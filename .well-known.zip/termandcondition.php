<?php  
include_once "View/top_file.php";
?>
</head>
<body>
<?php 
include_once "View/header.php";

?>
<div class="container">
<h2>Terms  & Conditions</h2>
<h4>Coming </h4>

</div>
<?php  include_once "View/fotter.php";

include_once "View/bottom_file.php";
?>

</body>
</html>