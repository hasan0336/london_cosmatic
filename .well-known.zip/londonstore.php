<?php  
include_once "View/top_file.php";
?>
</head>
<body>
<?php 
include_once "View/header.php";

?>
<div class="container">
<ul class="breadcrumb">
  <li><a href="index.php">Home</a></li>
  <li><a href="londonstore.php">London Store</a></li>
</ul>
</div>

<div class="container">
<br/>
<p>
All the product displayed on the website and additional pieces 
can be seen and purchased in our boutique in Marylebone.

<br/><br/>
Come and visit us for an in-person experience at:

<br/><br/>
<pre>
13d Crawford Street
Marylebone
W1U 6BZ 
</pre>
</p>
<div style="margin-top:250px;"></div>
<?php include_once "View/productslider.php";?>

</div>
<?php  include_once "View/fotter.php";

include_once "View/bottom_file.php";
?>

</body>
</html>