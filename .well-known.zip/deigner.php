<?php  
include_once "View/top_file.php";
?>
</head>
<body>
<?php 
include_once "View/header.php";

?>

<div class="container">
<ul class="breadcrumb">
  <li><a href="index.php">Home</a></li>
  <li><a href="designer.php">Designer</a></li>
</ul>
</div>

<div class="container">
<br/>
<h2>Designer Collaborations</h2>
<p>
Are you a designer? Do you see your collection fitting 
well with ours? We would be interested to hear from you.
 We offer retail space rental in our brick and mortar boutique 
 in Marylebone as well as do here. Send us an email
 for more information.
</p>
<div style="margin-top:250px;"></div>
<?php include_once "View/productslider.php";?>

</div>
<?php  include_once "View/fotter.php";

include_once "View/bottom_file.php";
?>

</body>
</html>