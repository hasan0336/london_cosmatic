<?php  
include_once "View/top_file.php";
?>
</head>
<body>
<?php 
include_once "View/header.php";

?>
<div class="container">
<ul class="breadcrumb">
  <li><a href="index.php">Home</a></li>
  <li><a href="careers.php">Careers</a></li>
</ul>
</div>
<div class="container">
<br/>
<h2>Careers</h2>
<p>
We currently have no vacancies

</p>
<div style="margin-top:250px;"></div>
<?php include_once "View/productslider.php";?>

</div>
<?php  include_once "View/fotter.php";

include_once "View/bottom_file.php";
?>

</body>
</html>