<div class="footer-content">
		<div class="sober-container">
			<h3 id="newsletter">Newsletter</h3>
<p id="para">Get timely updates from your favorite products</p>
<a><i class="fa fa-arrow-up" aria-hidden="true"></i></a>

<script>(function() {
	if ( ! window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push(
						{
							event   : event,
							callback: callback
						}
					);
				}
			}
		}
	}
})();
</script><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-306" method="post" data-id="306" data-name="Newsletter"><div class="mc4wp-form-fields"><input class="email" type="email" name="EMAIL" placeholder="Enter your email address" required="">
<input type="submit" value="Subscribe" class="form-btn">
</div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off"></label><input type="hidden" name="_mc4wp_timestamp" value="1578908096"><input type="hidden" name="_mc4wp_form_id" value="306"><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1"><div class="mc4wp-response"></div></form><!-- / Mailchimp for WordPress Plugin -->		</div>
	</div>
	

<div class="footer-widgets widgets-area widgets-4-columns">
		<div class="container">
			<div class="row">

				<div class="footer-widgets-area-1 footer-widgets-area col-xs-12 col-sm-6 col-md-4"></div><div class="footer-widgets-area-2 footer-widgets-area col-xs-12 col-sm-6 col-md-2"></div><div class="footer-widgets-area-3 footer-widgets-area col-xs-12 col-sm-6 col-md-2"></div><div class="footer-widgets-area-4 footer-widgets-area col-xs-12 col-sm-6 col-md-4"></div>
			</div>
		</div>
	</div>


<hr style="background-color: #f3dfc0;">

<footer>
      <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-6">
            

                <ul class="list-inline" style="margin-left: 12%;">
                                        <li><a href="aboutus.php" class="footer-link">About Us</a></li>
                                        <li><a href="contactus.php" class="footer-link">Contact Us</a></li>
                                        <li><a href="events.php" class="footer-link">Events</a></li>
                                        <li><a href="deliveryandreturn.php" class="footer-link">Delivery & Returns</a></li>
                    
                                        <li><a href="faqs.php" class="footer-link">FAQs</a></li>
                                        <li><a href="termandcondition.php" class="footer-link">Terms & Conditions</a></li>

                    
                </ul>
            </div>
            <!--<div class="col-md-3 col-sm-6 col-6">
               <!--<span class="sameheadingbot"><span class="samebigcharbot">P</span>RODUCTS</span>-->
                <!--                     <span class="sameheadingbot"><span class="samebigcharbot"></span>PRODUCTS</span>
                     

            <!--    <ul class="list-unstyled">-->
            <!--                            <li><a href="termandcondition.php" class="footer-link">Terms & Conditions</a></li>-->
                    
            <!--                            <li><a href="deigner.php" class="footer-link">Designer Collaborations</a></li>-->
                    
            <!--                            <li><a href="career.php" class="footer-link">Careers</a></li>-->
                    
            <!--                            <li><a href="contactus.php" class="footer-link">Contact Us</a></li>-->
                    

            <!--    </ul>-->
            <!--</div>-->
            
            <div class="col-md-6 col-sm-6 col-6">
                
                <!--<span class="sameheadingbot"><span class="samebigcharbot"></span>FOLLOW US ON SOCIAL MEDIA</span>-->
                <ul class="list-unstyled social-icons" style="margin-left: 65%;">
                    <!-- <li class="footer-insta"> -->
<a href="#" target="_blank" style="margin: 3%;"><i class="fab fa-instagram font-size-27 "></i></a>
                    <!-- </li> -->
                    <!-- <li class="footer-facebook"> -->
<a href="#" target="_blank" style="margin: 3%;"><i class="fab fa-facebook-square font-size-27 "></i></a>
                    <!-- </li> -->
                    <!-- <li class="footer-youtube"> -->
<a href="#" target="_blank" style="margin: 3%;"><i class="fab fa-youtube font-size-27 "></i></a>
                    <!-- </li> -->
                    <!-- <li class="footer-twitter"> -->
<a href="#" target="_blank" style="margin: 3%;"><i class="fab fa-twitter font-size-27 "></i></a>
                    
                    
                </ul>
            </div>
        </div>
    </div>

 

    
</footer>
<!--<footer class="copyright1">
    <div class="container">
        <div class="col-12  top-bottom-margin-10">
            <nav class="navbar navbar-expand-lg" style="margin-left: -4.5%;">
                <div class="col-6">
                    <ul class="navbar-nav display-vertical left-margin">
                        <li class="nav-item pad-5-10">
                            <a href="#"><img class="payment-logos" src="assets/img/Visa-dark.png"></a>
                        </li>
                        <li class="nav-item pad-5-10">
                            <a href="#"><img class="payment-logos" src="assets/img/MasterCard-dark.png"></a>
                        </li>
                        <li class="nav-item pad-5-10">
                            <a href="#"><img class="payment-logos" src="assets/img/Maestro-dark.png"></a>
                        </li>
                        <li class="nav-item pad-5-10">
                            <a href="#"><img class="payment-logos" src="assets/img/Paypal-dark.png"></a>
                        </li>
                    </ul>
                    
                </div>
               
                <div class="col-6">
                <!--<p class="united-kingdom" style="margin-right: -3.1%;">United Kingdom-£-English</p>
                <p class="copyright" style="margin-right: 12%;">copyrights &copy; 2019 offthecornerstore, All rights reserved</p>
                </div>
            </nav>
        </div>
         
    </div>-->
    <!--<div class="col-12">
        <!--Designed by S3 Technolohy
        <p class="copyright" style="margin-right: 12%;">copyrights &copy; 2019 offthecornerstore, All rights reserved</p>
    </div>-->

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
    $(function(){
     $('.fa.fa-arrow-up').click(function(){
      $('html,body').animate({
          scrollTop:0
      },500);
     });
   $('.cross').click(function(){
      $('#input').val("");
     });
     $('#input').keyup(function(){
         var value= $('#input').val();
        $.ajax({
         url:"product.php",
         method:"GET",
         data:{value:value},
         success:function(data){
             console.log(data);
         }
        });
     });
      });
    </script>