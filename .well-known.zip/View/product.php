<?php
$value=$_GET['value'];
echo $value;
?>