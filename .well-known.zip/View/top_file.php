<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>OFF THE CORNER</title>
    <link rel="shortcut icon" href="assets/img/logoT-black.png" />
    <base  />
    <meta name="description" content="My Store" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="assets/img/cart.png" rel="icon" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,400i,300,700" rel="stylesheet" type="text/css" />
    <link href="assets/css/stylesheet.css?v=0.039" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" type="text/css" rel="stylesheet" media="screen" />
    
     <!--Site CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="assets/css/versions.css>
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/custom.css"> 

    <!-- Magnify -->
    <link href="assets/css/zoom.css" rel="stylesheet">
    <link href="//db.onlinewebfonts.com/c/f99da0cc089925103ee1ecbcf5758240?family=Bodoni+SvtyTwo+ITC+TT" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script type="text/javascript">
      $('.grid').masonry({
          // options...
          itemSelector: '.grid-item',
          columnWidth: 140
        });
  </script>