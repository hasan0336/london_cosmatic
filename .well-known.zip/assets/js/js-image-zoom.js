    var options = {
    width: 400, // required
    // more options here
};
new ImageZoom(document.getElementById("img-container"), options);
var options = {
    width: 400, 
    height: auto
};
var options = {
    width: 400, 
    zoomWidth: auto
};
var options = {
    width: 400, 
    img: '<img src="Product/<?php echo $pro->product_name ;?>/<?php echo $pro->product_image;?>">'
};
var options = {
    width: 400, 
    offset: {
      vertical: 0,
      horizontal: 10
    }
};
var options = {
    width: 400, 
    scale: 2.5
};
var options = {
    width: 400, 
    zoomContainer: domNode
};
var options = {
    width: 1400, 
    zoomStyle: {
      // your css styles here
    }
};
var options = {
    width: 400, 
    zoomLensStyle: {
      // your css styles here
      
    }
};
var options = {
    width: 400, 
    zoomPosition: 'left'
};
